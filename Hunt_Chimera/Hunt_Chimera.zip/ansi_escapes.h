#pragma once
void setupConsole(void);
void restoreConsole(void);