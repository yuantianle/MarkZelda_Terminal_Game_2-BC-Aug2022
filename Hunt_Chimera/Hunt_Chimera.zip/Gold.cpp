/******************************************************
** Program: Gold.cpp
** Author:
** Date:
** Description:
** Input:
** Output:
******************************************************/
#include "Gold.h"
